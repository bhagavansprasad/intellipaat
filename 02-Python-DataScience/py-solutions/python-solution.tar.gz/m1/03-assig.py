def print_numbers(n):
    i = 1
    while(i <= n):
        print(i)
        i = i + 1

def main():
    print_numbers(10)
    
if __name__ == "__main__":
    main()
    