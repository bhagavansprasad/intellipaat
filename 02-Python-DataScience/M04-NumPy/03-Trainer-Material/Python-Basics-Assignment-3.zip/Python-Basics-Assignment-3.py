def question_01():
    n = 10
    r = 5
    p = 100
    
    A = p * ((1 + float(r/100)) ** n)
    print(A)

def question_02():
    # None
    pass

def main():
    question_01()
    
    # Q2 - None
    # Q3 - a
    # Q4 - b
    # Q5 - c
    
    
    

if __name__ == "__main__":
    main()
    
