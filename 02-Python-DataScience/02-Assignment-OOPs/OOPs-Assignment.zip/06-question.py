No abstrction class is possible in Python
